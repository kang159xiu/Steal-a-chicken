-- 功能开关只在每局初始化时读取。
-- 正式模块完成接线后按本表启用；临时 API 测试模块保持关闭。
local FeatureFlags = {
    Names = {
        "Tutorial",
        "GuideLineTest",
        "AvatarPictureBoardTest",
        "AvatarReadTest",
        "Persistence",
        "Zone",
        "Home",
        "Theft",
        "Guardian",
        "Inventory",
        "Hotbar",
        "Placement",
        "EggProduction",
        "EggCollection",
        "SellShop",
        "HomeUpgrade",
        "Treadmill",
        "Rebirth",
        "Purchase",
        "Prompt",
        "MultiplierPurchase",
        "TrackShop",
    },

    -- 仅用于避免共享开关在不需要该功能的端产生“未登记模块”警告。
    Scopes = {
        Tutorial = { Server = true, Client = true },
        GuideLineTest = { Server = false, Client = true },
        Persistence = { Server = true, Client = true },
        Zone = { Server = true, Client = false },
        Home = { Server = true, Client = true },
        Inventory = { Server = true, Client = false },
        Guardian = { Server = true, Client = false },
        Theft = { Server = true, Client = true },
        Hotbar = { Server = true, Client = true },
        Placement = { Server = true, Client = true },
        EggProduction = { Server = true, Client = true },
        EggCollection = { Server = true, Client = true },
        SellShop = { Server = true, Client = true },
        HomeUpgrade = { Server = true, Client = true },
        Treadmill = { Server = true, Client = true },
        Rebirth = { Server = true, Client = true },
        Purchase = { Server = true, Client = false },
        Prompt = { Server = false, Client = true },
        MultiplierPurchase = { Server = true, Client = true },
        TrackShop = { Server = true, Client = true },
    },

    Values = {
        Tutorial = true,
        GuideLineTest = false,
        -- 固定图标显示器头像测试暂时关闭，避免影响单独读取头像的结果。
        AvatarPictureBoardTest = false,
        -- 头像 API 返回0的问题暂时搁置，保留诊断代码但不运行。
        AvatarReadTest = false,
        Persistence = true,
        Zone = true,
        Home = true,
        -- 已验收玩法与正式快捷栏保持开启。
        Theft = true,
        Guardian = true,
        -- TheftService 的正式数据依赖，成功带回的鸡通过 InventoryService 入库。
        Inventory = true,
        Hotbar = true,
        Placement = true,
        EggProduction = true,
        EggCollection = true,
        SellShop = true,
        HomeUpgrade = true,
        Treadmill = true,
        Rebirth = true,
        Purchase = true,
        Prompt = true,
        MultiplierPurchase = true,
        TrackShop = true,
    },
}

return FeatureFlags
